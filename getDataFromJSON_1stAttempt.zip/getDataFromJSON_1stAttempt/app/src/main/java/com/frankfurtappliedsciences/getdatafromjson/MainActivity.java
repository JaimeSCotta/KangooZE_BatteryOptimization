package com.frankfurtappliedsciences.getdatafromjson;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    String urlJson = "";
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.tvJsonItem);

        new backgroundTask().execute();
    }

    public class backgroundTask extends AsyncTask<Void, Void, String>{

        ProgressDialog pd;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(MainActivity.this);
            pd.setTitle("Wait");
            pd.setMessage("Downloading...");
            pd.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            StringBuilder builder = null;
            urlJson = "https://jsonplaceholder.typicode.com/users";
            try {
                URL url = new URL(urlJson);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                InputStreamReader reader = new InputStreamReader(conn.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(reader);
                String line = "";
                builder = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null){
                    builder.append(line);
                }

            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return builder.toString();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();

            StringBuilder stringBuilder = new StringBuilder();

            try {
                JSONArray array = new JSONArray(s);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    String user = object.getString("name");
                    String address = object.getString("address");
                    JSONObject object1 = new JSONObject(address);
                    String city = object1.getString("city");

                    stringBuilder.append("Username is: "+ user +"\n city: "+ city + "\n");
                    textView.setText(stringBuilder.toString());


                    Log.e("User: ",user);
                    Log.e("Address: ",address);
                    Log.e("City: ",city);
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

        }
    }

}
