package com.frankfurtappliedsciences.testjsonimplementedonmain;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class activity_estimation extends AppCompatActivity {

    private ApiData apiData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimation);

        apiData = new ApiData(this);

    }
}