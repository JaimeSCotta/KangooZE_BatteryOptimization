package com.frankfurtappliedsciences.testjsonimplementedonmain;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submit = (Button) findViewById(R.id.btnHit);

        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                    Intent showEstimation = new Intent(getApplicationContext(), activity_estimation.class);
                    Toast.makeText(getApplicationContext(), "submit correctly", Toast.LENGTH_SHORT).show();
                    startActivity(showEstimation);
                }
        });
    }
}