package com.frankfurtappliedsciences.mqtt;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class activity_estimation extends AppCompatActivity {

    private int kangooBatteryLevel;
    private int batteryLevelCharge;
    private int horsCharging;
    TextView textView,textView2;
    private ApiData apiData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimation);
        textView = (TextView) findViewById(R.id.batLabel);
        textView2 = (TextView) findViewById(R.id.hourLabel);

        Intent receiverIntent = getIntent();
        String receivedValue = receiverIntent.getStringExtra("KEY_SENDER1");
        String receivedValue2 = receiverIntent.getStringExtra("KEY_SENDER2");
        String receivedValue3 = receiverIntent.getStringExtra("KEY_SENDER3");
        textView.setText(receivedValue);
        textView2.setText(receivedValue2);
        kangooBatteryLevel = Integer.parseInt(receivedValue3);
        batteryLevelCharge = Integer.parseInt(receivedValue2);
        horsCharging = Integer.parseInt(receivedValue);
        Log.d(TAG, "kangooBattLvl (h): " + kangooBatteryLevel);

        apiData = new ApiData(this);
    }


    private void estimation(int batteryLevelCharge, int horsCharging){

    }

}