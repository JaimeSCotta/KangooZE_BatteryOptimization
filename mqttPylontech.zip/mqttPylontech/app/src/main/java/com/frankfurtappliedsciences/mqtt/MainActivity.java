package com.frankfurtappliedsciences.mqtt;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText edtHour, edtBatteryPercentage, editBatKangoo;
    Button submit;
    private static boolean isInt =false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Call mqtt connection
        MqttConn mqttConn = new MqttConn(this);
        mqttConn.init();

        //Read the data introduced from the user
        edtHour = (EditText)findViewById(R.id.edtTimeChoosen);
        edtBatteryPercentage = (EditText)findViewById(R.id.edtBatteryChoosen);
        editBatKangoo = (EditText)findViewById(R.id.edtBatteryChoosen);
        submit = (Button) findViewById(R.id.btnSubmit);

        //When the button is pressed it will launch another activity (estimation layer)
        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(isNumeric(edtHour.getText().toString(), edtBatteryPercentage.getText().toString(),editBatKangoo.getText().toString())){

                    Intent showEstimation = new Intent(getApplicationContext(), activity_estimation.class);
                    showEstimation.putExtra("KEY_SENDER3", editBatKangoo.getText().toString());
                    showEstimation.putExtra("KEY_SENDER2", edtHour.getText().toString());
                    showEstimation.putExtra("KEY_SENDER1", edtBatteryPercentage.getText().toString());
                    Log.d(TAG, "kangooBatt (h): " + editBatKangoo.getText().toString());
                    Log.d(TAG, "batt (%): " + edtBatteryPercentage.getText().toString());
                    Log.d(TAG, "hour (h): " + edtHour.getText().toString());
                    Toast.makeText(getApplicationContext(), "submit correctly", Toast.LENGTH_SHORT).show();
                    startActivity(showEstimation);
                }else{
                    Toast.makeText(getApplicationContext(), "Error, you did not enter a number in the field", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    //Security method. Check if both values introduced are numeric
    public static boolean isNumeric(String aux, String aux2, String aux3) {
        try {
            Integer.parseInt(aux);
            Integer.parseInt(aux2);
            Integer.parseInt(aux3);
            isInt = true;
        } catch (NumberFormatException excepcion) {
            isInt = false;
        }
        return isInt;
    }
}

