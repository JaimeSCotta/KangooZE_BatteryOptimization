package com.frankfurtappliedsciences.mqtt;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MqttConn {

    private static final String TAG = "MyTag";
    private String topic , clientID;
    private MqttAndroidClient client;
    private Activity context;
    public double batteryCharge;

    private android.os.Handler handler;
    private static final int UPDATE_TEXT_VIEW = 1;

    public MqttConn(Activity context){
        this.context=context;
        batteryCharge = 1.0;
    }

    public interface MqttConnListener {
        void onBatteryChargeUpdated(double batteryCharge);
    }

    private MqttConnListener listener;

    public void setMqttConnListener(MqttConnListener listener) {
        this.listener = listener;
    }


    public void init(){
        clientID = "xxx";

        topic = "solpiplog/socvalue";
        client = new MqttAndroidClient(context, "tcp://192.168.208.114:1883", clientID);   // To use the HiveMQ broker use: tcp://broker.hivemq.com:1883

        handler = new android.os.Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == UPDATE_TEXT_VIEW) {
                    updateBatteryImg();
                }
            }
        };
        connect();
    }

    private void connect(){
        try {
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "onSuccess");
                    sub();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.d(TAG, "onFailure");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    private void sub() {
        try {
            client.subscribe(topic, 2);
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    Toast.makeText(context, "ConnLost", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "ConnLost");
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String data = new String(message.getPayload());
                    Log.d(TAG, "topic: " + topic);
                    Log.d(TAG, "message: " + data);
                    batteryCharge = Double.parseDouble(data);
                    if (listener != null) {
                        listener.onBatteryChargeUpdated(batteryCharge);
                    }

                    Message updateMsg = handler.obtainMessage(UPDATE_TEXT_VIEW, batteryCharge);
                    handler.sendMessage(updateMsg);
                    client.close();
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    Log.d(TAG, "deliveryComplete");
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    private void updateBatteryImg(){
        TextView textView = ((Activity)context).findViewById(R.id.percentageLabel);
        textView.setText(batteryCharge + "%");

        ImageView batteryImage = ((Activity)context).findViewById(R.id.baterryImage);
        Resources res = ((Activity)context).getResources();
        if(batteryCharge >= 90){
            batteryImage.setImageDrawable(res.getDrawable(R.drawable.fullcharge));
        }else if (90 > batteryCharge && batteryCharge >= 75){
            batteryImage.setImageDrawable(res.getDrawable(R.drawable.fullmedcharge));
        }else if (75 > batteryCharge && batteryCharge >= 50){
            batteryImage.setImageDrawable(res.getDrawable(R.drawable.medcharge));
        }else if (50 > batteryCharge && batteryCharge >= 30){
            batteryImage.setImageDrawable(res.getDrawable(R.drawable.medlowcharge));
        }else if (30 > batteryCharge && batteryCharge >= 15){
            batteryImage.setImageDrawable(res.getDrawable(R.drawable.lowcharge));
        }else {
            batteryImage.setImageDrawable(res.getDrawable(R.drawable.verylowcharge));
        }
    }
}
