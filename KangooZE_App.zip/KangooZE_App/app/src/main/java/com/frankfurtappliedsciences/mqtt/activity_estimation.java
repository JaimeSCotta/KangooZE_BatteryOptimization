package com.frankfurtappliedsciences.mqtt;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.ListIterator;

public class activity_estimation extends AppCompatActivity implements ApiData.EnergyValuesCallback {

    /* Constants */
    private final double KangooCapacity = 22; //kWh
    private final double pylontechCapacity = 3.6; //kWh
    private final double surfacePV = 4.958; //m2

    /* Variables */
    private boolean chargingKangooBattery = false;
    private boolean chargingPylontechBattery = false;
    private boolean completeKangooCharge = false;
    private boolean completePylontechCharge = false;
    private boolean posibleCharge = false;
    private boolean pylontechDischarged = false;
    private double kangooBatteryLevel;
    private double pylontechSoC;
    private double percentageToKwhBattery;
    private double percentageToKwhRequested;
    private double percentageToKwhPylontech;
    private double chargeNecessaryKangooBatt;
    private double chargeNecessaryPylontechBatt;
    private double accumulatedKangooCharge = 0.0;
    private double accumulatedPylontechCharge = 0.0;

    private int necessaryHours = 0;
    private int horsCharging = 0;
    private double batteryLevelCharge;
    TextView textView;
    private ApiData apiData;
    private LinkedList energyValues, energyIcons;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimation);
        statusBarColor();
        textView = findViewById(R.id.resultLabel);

        Intent receiverIntent = getIntent();
        String receivedValueHours = receiverIntent.getStringExtra("KEY_SENDER1");
        String receivedValueBatteryRequested = receiverIntent.getStringExtra("KEY_SENDER2");
        String receivedValueBatterySoC = receiverIntent.getStringExtra("KEY_SENDER3");
        String receivedValuePylontechSoC = receiverIntent.getStringExtra("KEY_SENDER4");

        horsCharging = Integer.parseInt(receivedValueHours);
        batteryLevelCharge = Double.parseDouble(receivedValueBatteryRequested);
        kangooBatteryLevel = Double.parseDouble(receivedValueBatterySoC);
        pylontechSoC = Double.parseDouble(receivedValuePylontechSoC);

        Log.d(TAG, "Received -> horsCharging (h): " + horsCharging);
        Log.d(TAG, "Received -> batteryLevelCharge (%): " + batteryLevelCharge);
        Log.d(TAG, "Received -> kangooBattLvl (%): " + kangooBatteryLevel);
        Log.d(TAG, "Received -> pylontechSoC (%): " + pylontechSoC);

        apiData = new ApiData(this, this);
    }


    public void getEnergyV( LinkedList energyVal) {
        ListIterator iterator = energyVal.listIterator();

        while (iterator.hasNext()){
            Log.d(TAG, "energyValue: " + iterator.next().toString());
        }
    }

    // Wait till the new energy values are received form the API and execute the estimation method
    @Override
    public void onEnergyValuesReceived(LinkedList energyValues, LinkedList energyIcons) {
        this.energyValues = energyValues;
        this.energyIcons = energyIcons;
        estimation(batteryLevelCharge, horsCharging, kangooBatteryLevel);
    }



    private void estimation(double batteryLevelCharge, int horsCharging, double kangooBatteryLevel){

        ListIterator iterator = energyValues.listIterator();
        updateDayImg();

        double pvEnergy =0.0;

        percentageToKwhBattery = (kangooBatteryLevel * KangooCapacity)/100;
        percentageToKwhRequested =(batteryLevelCharge * KangooCapacity)/100;
        percentageToKwhPylontech = (pylontechSoC * pylontechCapacity)/100;

        chargeNecessaryKangooBatt = percentageToKwhRequested - percentageToKwhBattery; //kWh
        chargeNecessaryPylontechBatt = pylontechCapacity - percentageToKwhPylontech;

        Calendar calendar = Calendar.getInstance();
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int hAux1 = 0,hAux2 = 0;

        if(chargeNecessaryPylontechBatt == 0){
            chargingPylontechBattery = false;
            accumulatedPylontechCharge = pylontechCapacity;
        }
        else {
            chargingPylontechBattery = true;
            Log.d(TAG, "-> Pylontech Charge Neccessary: " + chargeNecessaryPylontechBatt);
        }

        if(chargeNecessaryKangooBatt == 0){
            chargingKangooBattery = false;
        }
        else {
            chargingKangooBattery = true;
            Log.d(TAG, "-> KangooZE Charge Neccessary: " + chargeNecessaryKangooBatt);
        }

        // "Do not read values before the current time.
        // Start receiving energy values from the moment the application is executed"
        for (int i = 0; i < h; i++) {
            Log.d(TAG, "Skiping hours till reach NOW: " + iterator.next());
            hAux1 ++;
            hAux2 ++;
        }



        while(!completeKangooCharge){
            while (!completePylontechCharge) {
                if (hAux2 >= 21) {
                    posibleCharge = false;
                    completePylontechCharge = true;
                }
                else {
                    if(pylontechDischarged){
                        chargeNecessaryPylontechBatt = pylontechCapacity;
                    }
                    double energyReceived = Double.parseDouble(iterator.next().toString());
                    pvEnergy = ((surfacePV * energyReceived)/ 1000) * 0.90;
                    Log.d(TAG, "-> Energy received: " + energyReceived);
                    Log.d(TAG, "-> Acumulated Pylontech Energy... " + accumulatedPylontechCharge);
                    accumulatedPylontechCharge = accumulatedPylontechCharge + pvEnergy;
                    necessaryHours++;
                    hAux2++;
                    hAux1++;
                    Log.d(TAG, "-> Charging Pylontech... " + accumulatedPylontechCharge);
                    Log.d(TAG, "necessaryHours: " + necessaryHours);

                    if (accumulatedPylontechCharge >= chargeNecessaryPylontechBatt) {
                        completePylontechCharge = true;
                        Log.d(TAG, "-> Pylontech Charge completed !!");
                        accumulatedPylontechCharge = pylontechCapacity;
                    }
                }
            }

            if (hAux1 >= 21) {
                posibleCharge = false;
                completeKangooCharge = true;
            }

            pvEnergy = ((surfacePV * Double.parseDouble(iterator.next().toString()))/1000)*0.90;

            Log.d(TAG, "-> Actual Pylontech Charge before charge kangoo: "+ accumulatedPylontechCharge);
            accumulatedKangooCharge = accumulatedKangooCharge + pvEnergy + (0.288*0.75);
            necessaryHours ++;
            hAux2 ++;
            hAux1 ++;
            //pylon discharge:
            accumulatedPylontechCharge = accumulatedPylontechCharge - 0.288;
            Log.d(TAG, "-> Actual Pylontech Charge after charge kangoo: "+ accumulatedPylontechCharge);

            Log.d(TAG, "-> Charging Kangoo ZE ... " + accumulatedKangooCharge);
            Log.d(TAG, "necessaryHours: " + necessaryHours);

            if (accumulatedPylontechCharge < 1.08){ //do not go down of the ~30% of the Pylontech battery charge
                completePylontechCharge = false;
                pylontechDischarged = true;
                Log.d(TAG, "-> !! Pylontech Discharged !!");
            }

            if(accumulatedKangooCharge >= chargeNecessaryKangooBatt){
                completeKangooCharge = true;
                Log.d(TAG, "-> Kangoo ZE Charge completed !!");
                posibleCharge = true;
            }
        }


        if((!posibleCharge) | (necessaryHours > horsCharging)){
            if(!posibleCharge){
                textView.setText("We are sorry, but the charge is not possible during the specified "+ horsCharging + " hour period.\nThank you for understanding!" +
                        "\nIt will get dark and no more charging is avaliable. Try a lower charging instead!.");
            }
            else {
                textView.setText("We are sorry, but the charge is not possible during the specified "+ horsCharging + " hour period. Thank you for understanding!" +
                        "\nThe minimum hours needed are: "+ necessaryHours+"h");
            }
        }
        else {
            textView.setText("The charge is possible for the requested period of time.\nExact time needed: "+necessaryHours+"h");
        }
    }

    private void updateDayImg(){
        ImageView energyImage = findViewById(R.id.weatherImg);
        ListIterator iteratorIcons = energyIcons.listIterator();

        String img = iteratorIcons.next().toString();

        switch (img){
            case "clear-day":
                energyImage.setImageDrawable(getDrawable(R.drawable.clear_day));
                break;
            case "clear-night":
                energyImage.setImageDrawable(getDrawable(R.drawable.clear_night));
                break;
            case "cloudy":
                energyImage.setImageDrawable(getDrawable(R.drawable.cloudy));
                break;
            case "fog":
                energyImage.setImageDrawable(getDrawable(R.drawable.fog));
                break;
            case "hail":
                energyImage.setImageDrawable(getDrawable(R.drawable.hail));
                break;
            case "partly-cloudy-day":
                energyImage.setImageDrawable(getDrawable(R.drawable.partly_cloudy_day));
                break;
            case "partly-cloudy-night":
                energyImage.setImageDrawable(getDrawable(R.drawable.partly_cloudy_night));
                break;
            case "rain":
                energyImage.setImageDrawable(getDrawable(R.drawable.rain));
                break;
            case "rain-snow":
                energyImage.setImageDrawable(getDrawable(R.drawable.rain_snow));
                break;
            case "rain-snow-showers-day":
                energyImage.setImageDrawable(getDrawable(R.drawable.rain_snow_showers_day));
                break;
            case "rain-snow-showers-night":
                energyImage.setImageDrawable(getDrawable(R.drawable.rain_snow_showers_night));
                break;
            case "showers-day":
                energyImage.setImageDrawable(getDrawable(R.drawable.showers_day));
                break;
            case "showers-night":
                energyImage.setImageDrawable(getDrawable(R.drawable.showers_night));
                break;
            case "sleet":
                energyImage.setImageDrawable(getDrawable(R.drawable.sleet));
                break;
            case "snow":
                energyImage.setImageDrawable(getDrawable(R.drawable.snow));
                break;
            case "snow-showers-day":
                energyImage.setImageDrawable(getDrawable(R.drawable.snow_showers_day));
                break;
            case "snow-showers-night":
                energyImage.setImageDrawable(getDrawable(R.drawable.snow_showers_night));
                break;
            case "thunder":
                energyImage.setImageDrawable(getDrawable(R.drawable.thunder));
                break;
            case "thunder-rain":
                energyImage.setImageDrawable(getDrawable(R.drawable.thunder_rain));
                break;
            case "thunder-showers-day":
                energyImage.setImageDrawable(getDrawable(R.drawable.thunder_showers_day));
                break;
            case "thunder-showers-night":
                energyImage.setImageDrawable(getDrawable(R.drawable.thunder_showers_night));
                break;
            case "wind":
                energyImage.setImageDrawable(getDrawable(R.drawable.wind));
                break;
            default:
                energyImage.setImageDrawable(getDrawable(R.drawable.cloudwithsun));
                break;
        }

    }
    private void statusBarColor(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            getWindow().setStatusBarColor(getResources().getColor(R.color.lightBlue, this.getTheme()));
        }else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            getWindow().setStatusBarColor(getResources().getColor(R.color.lightBlue));
        }
    }
}