package com.frankfurtappliedsciences.mqtt;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;


public class ApiData {

    private Activity context;
    TextView txtJson;
    ProgressDialog pd;
    private LinkedList energyValues = new LinkedList();
    private LinkedList energyIcons = new LinkedList();
    private EnergyValuesCallback callback;


    public ApiData(Activity context, EnergyValuesCallback callback) {
        this.context = context;
        this.callback = callback;
        new JsonTask().execute("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/Frankfurt?unitGroup=metric&key=VY6RFJH3L2GT57SKLFUUFX7L6&contentType=json&elements=datetime,icon,ghiradiation,dniradiation,difradiation,gtiradiation,sunazimuth,sunelevation&solarTiltAngle=45");
    }


    public interface EnergyValuesCallback {
        void onEnergyValuesReceived(LinkedList energyValues, LinkedList energyIcons);
    }

    private class JsonTask extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog((Activity)context);
            pd.setMessage("Please wait");
            pd.setCancelable(false);
            pd.show();
        }


        protected String doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                    Log.d("Response: ", "> " + line);
                }
                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (pd.isShowing()) {
                pd.dismiss();
            }

            StringBuilder stringBuilder = new StringBuilder();
            try {
                JSONObject jsonObject = new JSONObject(result);
                String days = jsonObject.getString("days");
                JSONArray array = new JSONArray(days);

                for (int i = 0;  i< array.length(); i++) {
                    JSONObject jsonObject2 = array.getJSONObject(i);

                    String dateTime = jsonObject2.getString("datetime");
                    stringBuilder.append("\n /*____ Date Time: " + dateTime + " ____*/");

                    String energyIcon = jsonObject2.getString("icon");
                    energyIcons.add(energyIcon);

                    String hours = jsonObject2.getString("hours");
                    JSONArray hoursArray = new JSONArray(hours);

                    for (int j = 0;  j< hoursArray.length(); j++) {
                        JSONObject jsonObject3 = hoursArray.getJSONObject(j);
                        String ghiradiation = jsonObject3.getString("ghiradiation");
                        String datetime = jsonObject3.getString("datetime");

                        energyValues.add(ghiradiation);

                        stringBuilder.append("\n Time (h): " + datetime + " | Corresponding GHI: "+ ghiradiation);
                    }

                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
            if (callback != null) {
                callback.onEnergyValuesReceived(energyValues, energyIcons);
            }
        }
    }
}

