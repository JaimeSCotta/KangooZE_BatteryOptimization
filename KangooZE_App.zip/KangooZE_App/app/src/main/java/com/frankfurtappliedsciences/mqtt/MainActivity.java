package com.frankfurtappliedsciences.mqtt;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity implements MqttConn.MqttConnListener{

    EditText edtHour, edtBatteryPercentage, editBatKangoo;
    double pylontechSoC = 1.0;
    Button submit;
    private static boolean isInt =false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusBarColor();

        ImageView batteryImage = this.findViewById(R.id.baterryImage);
        batteryImage.setImageDrawable(getDrawable(R.drawable.medlowcharge));

        //Call mqtt connection
        MqttConn mqttConn = new MqttConn(this);
        mqttConn.setMqttConnListener(this);
        mqttConn.init();

        //Read the data introduced from the user
        edtHour = (EditText)findViewById(R.id.edtTimeChoosen);
        edtBatteryPercentage = (EditText)findViewById(R.id.edtBatteryChoosen);
        editBatKangoo = (EditText)findViewById(R.id.editBatKangoo);
        submit = (Button) findViewById(R.id.btnSubmit);

        //When the button is pressed it will launch another activity (estimation layer)
        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(isAccepted(edtHour.getText().toString(), edtBatteryPercentage.getText().toString(),editBatKangoo.getText().toString())){

                    Intent showEstimation = new Intent(getApplicationContext(), activity_estimation.class);
                    showEstimation.putExtra("KEY_SENDER1", edtHour.getText().toString());
                    showEstimation.putExtra("KEY_SENDER2", edtBatteryPercentage.getText().toString());
                    showEstimation.putExtra("KEY_SENDER3", editBatKangoo.getText().toString());
                    showEstimation.putExtra("KEY_SENDER4", String.valueOf(pylontechSoC));

                    Log.d(TAG, "Sending -> hoursCharging (h): " + edtHour.getText().toString());
                    Log.d(TAG, "Sending -> battRequested (%): " + edtBatteryPercentage.getText().toString());
                    Log.d(TAG, "Sending -> kangooBatt (h): " + editBatKangoo.getText().toString());
                    Log.d(TAG, "Sending -> pylontechSoC: " + pylontechSoC);

                    Toast.makeText(getApplicationContext(), "submit correctly", Toast.LENGTH_SHORT).show();
                    startActivity(showEstimation);
                }else{
                    Toast.makeText(getApplicationContext(), "Oops, you typed incorrect values", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // Wait till the new MQTT value is received and do the corresponding actions
    @Override
    public void onBatteryChargeUpdated(double batteryCharge) {
        pylontechSoC = batteryCharge;

    }

    //Security method. Check if both values introduced are numeric
    public static boolean isAccepted(String hour, String battRequested, String kangooSoC) {
        try {
            Integer.parseInt(hour);
            Integer.parseInt(battRequested);
            Integer.parseInt(kangooSoC);
            isInt = true;
            if (Integer.parseInt(kangooSoC) >= Integer.parseInt(battRequested)){
                isInt = false;
            }
        } catch (NumberFormatException excepcion) {
            isInt = false;
        }
        return isInt;
    }

    private void statusBarColor(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            getWindow().setStatusBarColor(getResources().getColor(R.color.lightBlue, this.getTheme()));
        }else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            getWindow().setStatusBarColor(getResources().getColor(R.color.lightBlue));
        }
    }
}

